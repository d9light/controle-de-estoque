<?php
//Importou a classe usuário da controller
use Controller\UsuarioController;
//Autoload e cabeçalho
require_once 'vendor/autoload.php';
require_once './shared/header.php';

$usuarios = new UsuarioController;

if ($_REQUEST) {

    //Variável chamada ID
    if(isset($_REQUEST['id'])){
        $id = $_REQUEST['id'];
        //Pega o id da url e carrega o objeto do usuario a ser editado.
        $objetoUsuario = $usuarios->loadById($id);

        //Exclui o registro.
        if($_REQUEST['cod']=='excluir'){
            $usuarios->delete($id);
        }

    }

    //Variável COD
    if ($_REQUEST['cod'] == 'success') {
        echo '<divclass="alert alert-primary alert-dismissible fade show" role="alert">
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close"
                    ></button>
                    <strong>Registro inserido com sucesso.</strong> Alert Content
                </div>';
    }else if($_REQUEST['cod']=='error'){

        echo '<divclass="alert alert-danger alert-dismissible fade show" role="alert">
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close"
                    ></button>
                    <strong>Ocorreu um erro.</strong> Alert Content
                </div>';

    }
}

?>
<!-- HTML AQUI -->
<form method="post" action="<?php $usuarios->save(); ?>">

    <input type="hidden" name="id" value="<?php echo(empty($objetoUsuario)? '': $objetoUsuario->getId());?>">
    <div class="mb-3">
        <label for="" class="form-label">Nome</label>
        <input type="text" class="form-control" name="nome" value="<?php echo(empty($objetoUsuario)? '': $objetoUsuario->getNome());?>" placeholder="Insira seu nome" />
    </div>
    <div class="mb-3">
        <label for="" class="form-label">E-mail</label>
        <input type="email" class="form-control" name="email" value="<?php echo(empty($objetoUsuario)? '': $objetoUsuario->getEmail());?>" placeholder="Insira seu email" />
    </div>
    <div class="mb-3">
        <label for="" class="form-label">Senha</label>
        <input type="text" class="form-control" name="senha" value="<?php echo(empty($objetoUsuario)? '': $objetoUsuario->getSenha());?>" placeholder="Insira sua senha" />
    </div>

    <input type="submit" value="Salvar" class="btn btn-success">
</form>

<?php
require_once './shared/footer.php';
?>