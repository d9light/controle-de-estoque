<?php
require_once './shared/header.php';


use Controller\TarefasController;
require_once 'vendor/autoload.php';


?>


        <br>
        
        <div class="mb-4 container">
        <h1 class="mb-4">Tarefas</h1>
            
            <form>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <!-- TODO: Implemente a funcionalidade de filtrar tarefas por projeto selecionado - PONTO EXTRA (Não apagar TODO.) -->
                            <label for="filtroProjeto" class="form-label">Filtrar por Projeto</label>
                            <select class="form-select" id="filtroProjeto">
                                <option selected>Escolha um projeto...</option>
                                <option value="1">Projeto 1</option>
                                <option value="2">Projeto 2</option>
                            </select>
                        </div>
                    </div>
                </div>
               
                <input type="submit" class="btn btn-primary" value="Aplicar filtro">
            </form>
        </div>


        <!-- Tabela de Tarefas -->
        <div class="d-flex justify-content-between mb-4 container">
                <h4>Lista de Tarefas</h4>
                <!-- TODO: Implementar a funcionalidade de cadastrar nova tarefa - PONTO EXTRA (Não apagar TODO.) -->
                <a href="manterTarefa.php" class="btn btn-primary">Nova Tarefa</a>
            </div>
        <div class="table-responsive container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nome da Tarefa</th>
                        <th>Descrição</th>
                        <th>Status</th>
                        <th>Prazo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tarefa Exemplo 1</td>
                        <td>Descrição da tarefa 1</td>
                        <td>Pendente</td>
                        <td>2024-10-01</td>
                        <td>
                             <!-- TODO: Implente o CRUD das tarefas - PONTO EXTRA (Não apagar TODO.) -->
                            <button class="btn btn-sm btn-warning">Editar</button>
                            <button class="btn btn-sm btn-danger">Excluir</button>
                            <button class="btn btn-sm btn-success">Concluir</button>
                        </td>
                    </tr>


                    <?php
            //Instancia o objeto usuarios da controller
            $tarefas = new TarefasController;

            //$result é o array que carrega a lista de usuários
            $result = $tarefas->loadAll();
            foreach ($result as $key => $value) {

                if($value['status_id'] == 2){
                    $value['status_id'] = 'Em andamento';

                }
                elseif ($value['status_id'] == 3) {
                    $value['status_id'] = 'Concluído';

                }
                elseif ($value['status_id'] == 1) {
                    $value['status_id'] = 'Pendente';

                }


                echo '<tr class="">';
                    echo ' <td>'.$value['nome'].'</td>';
                    echo ' <td>'.$value['descricao'].'</td>';
                    echo ' <td>'.$value['status_id'].'</td>';
                    echo ' <td>'.$value['prazo'].'</td>';


                    
                    echo ' <td>
                                <a href="manterTarefa.php?id='.$value['id'].'&&cod=editar" class="btn btn-sm btn-warning">Editar</a>
                                <a href="manterTarefa.php?id='.$value['id'].'&&cod=excluir" class="btn btn-sm btn-danger">Excluir</a>
                                <a href="manterTarefa.php?id='.$value['id'].'&&cod=concluir" class="btn btn-sm btn-success">Concluir</a>

                                </td>';
                echo ' </tr>';
            }
            ?>

                     <!-- TODO: Adicione as tarefas dinamicamente - 1 PONTO (Não apagar TODO.) -->
                </tbody>
            </table>
        </div>
    </div>
<?php
require_once './shared/footer.php';
?>