<?php
require_once './shared/header.php';
?>

<div class="container my-4">
        <h1 class="mb-4">Cadastro de Novo Projeto</h1>

          <?php
            use Controller\ProjetoController;
            require 'vendor/autoload.php';
            $p = new ProjetoController;


            if ($_REQUEST) {

                
                //Variável chamada ID
                if(isset($_REQUEST['id'])){
                    $id = $_REQUEST['id'];
                    //Pega o id da url e carrega o objeto do usuario a ser editado.
                    $objetoProjeto = $p->loadById($id);
                    
                    //Exclui o registro.
                    if($_REQUEST['cod']=='excluir'){
                        $p->delete($id);
                    }
            
                }
            }
             ?>
    

            <form method="POST" action="<?php $p->save()?>">
            <input type="text" name="id" value="<?php echo(empty($objetoProjeto)? '0': $objetoProjeto->getId());?>" hidden>
            <div class="mb-3">
                <label for="nomeProjeto" class="form-label">Nome do Projeto</label>
                <input type="text" class="form-control" id="nomeProjeto" name="nome" value="<?php echo(empty($objetoProjeto)? '': $objetoProjeto->getNome());?>"  required>
            </div>
            <div class="mb-3">
                <label for="descricaoProjeto" class="form-label">Descrição</label>
                <textarea class="form-control" id="descricaoProjeto" name="descricao" rows="3" required><?php echo(empty($objetoProjeto) ? '' : $objetoProjeto->getDescricao()); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="statusProjeto" class="form-label">Status</label>
                <select class="form-select" id="statusProjeto" name="status" required>
    <!-- TODO: Adicione os status dinamicamente - Contempla funcionalidade de cadastrar e editar projeto (Não apagar TODO.) -->
                <option value="1" <?php echo (!empty($objetoProjeto) && $objetoProjeto->getStatusId() == 1) ? 'selected' : ''; ?>>Em Andamento</option>
                <option value="2" <?php echo (!empty($objetoProjeto) && $objetoProjeto->getStatusId() == 2) ? 'selected' : ''; ?>>Concluído</option>
                </select>

            </div>
            <div class="mb-3">
                <label for="dataInicio" class="form-label">Data de Início</label>
                <input type="date" class="form-control" id="dataInicio" name="data_inicio" value="<?php echo(empty($objetoProjeto)? '': $objetoProjeto->getDataInicio());?>" required>
            </div>
            <div class="mb-3">
                <label for="dataFim" class="form-label">Data de Término</label>
                <input type="date" class="form-control" id="dataFim" name="data_fim" value="<?php echo(empty($objetoProjeto)? '': $objetoProjeto->getDataFim());?>" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Salvar">
            <a href="listarProjetos.php" class="btn btn-secondary">Cancelar</a>
        </form>
   
        </div>
