
<?php
             
             use Controller\UsuarioController;
             require 'vendor/autoload.php';
             $user = new UsuarioController;

             ?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gerenciador de Projetos</title>
    <link href="\ava2/src/css/bootstrap.min.css" rel="stylesheet">
    <script src="\ava2/src/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container vh-100 d-flex justify-content-center align-items-center">
        <div class="card shadow-lg p-4" style="width: 400px;">
            <img width="80%" class="text-center" src="\ava2/src/img/logo.png">
            <h2 class="text-center mb-4">Login</h2>
            <!-- : Implementar funcionalidade de logar no sistema sem Cookies - 1 PONTO (Não apagar TODO.) -->
            <form method="post" action="<?php $user->login(); ?>">
                <div class="mb-3">
                    <label for="" class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Senha:</label>
                    <input type="password" class="form-control" name="senha" required>
                </div>
                <input class="btn btn-primary" type="submit" value="Login" />
                <!-- TODO: Implementar cadastro de usuário - 1 PONTO. Usuários criados aqui são do tipo_usuario="Usuário" (Não apagar TODO.) -->
                <p class="text-center mt-3">Não tem uma conta? <a href="cadastro.php">Cadastre-se</a></p>
            </form>
            
       
<?php
 if (@$_REQUEST['cod'] == 'error') {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Ocorreu um erro.</strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
} else if (@$_REQUEST['cod'] == '172') {
    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Suas sessão expirou.</strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
}
?>
</div>
</div>
    
</body>
</html>
