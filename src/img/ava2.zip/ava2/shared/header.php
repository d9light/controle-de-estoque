
<?php
             
             use Controller\UsuarioController;
             require 'vendor/autoload.php';
             $user = new UsuarioController;
             require_once './shared/header.php';
             require_once 'src\controller\AutenticationController.php';

             ?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projetos - Gerenciador de Projetos</title>
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous" />
    <script src="\ava2/src/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
        <div class="container-fluid">
            <img style="width: 5%; float:left;" src="\ava2/src\img\logo.png" alt="Logo">
            <a class="navbar-brand text-left" style="float: left;" href="listarProjetos.php">Gerenciador de Projetos</a>
            <a class="navbar-brand text-left" style="float: left; padding-left: 20px;" href="listarTarefas.php">Tarefas</a>
            <!-- TODO: Implementar logout do sistema - Funcionalidade de login (Não apagar TODO.) -->
            <a href="src\controller\LogoutController.php"class="btn btn-outline-danger ms-auto">Sair</a></div>
    </nav>
    <main>


    <?php
 if (@$_REQUEST['cod'] == 'error') {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Ocorreu um erro.</strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
} else if (@$_REQUEST['cod'] == 'success') {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Sua ação foi realizada com sucesso.</strong>  
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
}
?>