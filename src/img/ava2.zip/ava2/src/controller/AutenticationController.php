<?php

namespace Controller;

@session_start();
//Se não existir a session login
if(!isset($_SESSION['id'])){
    header('location: \ava2/index.php?cod=172');
}