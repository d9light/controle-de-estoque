<?php

namespace Controller;

session_start();
session_abort();
session_destroy();

header('Location: \ava2/index.php?cod=172');

exit();
