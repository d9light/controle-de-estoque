<?php
namespace Controller;

use Model\ProjetoModel;

require './vendor/autoload.php';
@session_start();

class ProjetoController
{

    public function save()
    {
        if ($_POST ) {
            $projeto = new ProjetoModel;

            $projeto->setId($_POST['id']);
            $projeto->setNome($_POST['nome']);
            $projeto->setDescricao($_POST['descricao']);
            $projeto->setDataInicio($_POST['data_inicio']);
            $projeto->setDataFim($_POST['data_fim']);
            $projeto->setStatusId($_POST['status']);
            $projeto->setUsuarioId($_SESSION['id']);
            $projeto->save();
            if($projeto->total > 0){
                //success
                //Não precisa mais colocar ../ somente colocar \ que redireciona para a raiz.
                header('location: \ava2/manterprojeto.php?cod=success');
            }else{
                //error
               header('location: \ava2/manterprojeto.php?cod=error');
            }
        }
    
    }

    public function loadAll()
    {
        $projeto = new ProjetoModel;
        $result = $projeto->loadAll(); //$result é uma array que retorna do banco de dados.
        return $result;
    }

    
    public function loadById($id)
    {
        $projeto = new ProjetoModel;
        $projeto = $projeto->loadById($id); //loadbyId está na model agora e retorna um objeto do tipo usuário
        return $projeto;
    }

    
public function delete($id)
{
    $projeto = new ProjetoModel;
    $projeto->delete($id);
    if($projeto->total > 0){
        header('location: \ava2/listarProjetos.php?cod=success');
    }else{
        header('location: \ava2/listarProjetos.php?cod=error');
    }
}

}
