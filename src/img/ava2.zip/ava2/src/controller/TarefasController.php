<?php
namespace Controller;

use Model\TarefasModel;

require './vendor/autoload.php';
@session_start();

class TarefasController
{

    public function save()
    {
        if ($_POST ) {
            $tarefas = new TarefasModel;

            $tarefas->setId($_POST['id']);
            $tarefas->setNome($_POST['nome']);
            $tarefas->setDescricao($_POST['descricao']);
            $tarefas->setPrazo($_POST['prazo']);
            $tarefas->setProjetoId($_POST['projeto_id']);
            $tarefas->setStatusId($_POST['status_id']);
            $tarefas->save();
            if($tarefas->total > 0){
                //success
                //Não precisa mais colocar ../ somente colocar \ que redireciona para a raiz.
                header('location: \ava2/manterTarefa.php?cod=success');
            }else{
                //error
               header('location: \ava2/manterTarefa.php?cod=error');
            }
        }
    
    }

    public function loadAll()
    {
        $tarefas = new TarefasModel;
        $result = $tarefas->loadAll(); //$result é uma array que retorna do banco de dados.
        return $result;
    }

    function loadCostumerById($id){
        require_once './model/customersModel.php';
        $tarefas = new TarefasModel();
        //Imprime no select de veículos
        return $tarefas->getProjeto($id);
    }

    
    public function loadById($id)
    {
        $tarefas = new TarefasModel;
        $tarefas = $tarefas->loadById($id); //loadbyId está na model agora e retorna um objeto do tipo usuário
        return $tarefas;
    }

    
public function delete($id)
{
    $tarefas = new TarefasModel;
    $tarefas->delete($id);
    if($tarefas->total > 0){
        header('location: \ava2/listartarefas.php?cod=success');
    }else{
        header('location: \ava2/listartarefas.php?cod=error');
    }
}



}
