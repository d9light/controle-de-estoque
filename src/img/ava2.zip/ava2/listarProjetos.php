<?php
require_once './shared/header.php';
use Controller\ProjetoController;
require_once 'vendor/autoload.php';

?>
        <div class="container my-4">
            <h1 class="mb-4">Projetos</h1>
            <div class="d-flex justify-content-between mb-4">
                <h4>Lista de Projetos</h4>
                <!-- TODO: Implementar a funcionalidade de cadastrar novo projeto - 1 PONTO (Não apagar TODO.) -->
                <a href="manterProjeto.php" class="btn btn-primary">Novo Projeto</a>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nome do Projeto</th>
                            <th>Descrição</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                   

                            <?php
            //Instancia o objeto usuarios da controller
            $projetos = new ProjetoController;

            //$result é o array que carrega a lista de usuários
            $result = $projetos->loadAll();
            foreach ($result as $key => $value) {
                echo '<tr class="">';
                    echo ' <td>'.$value['nome'].'</td>';
                    echo ' <td>'.$value['descricao'].'</td>';
                    echo ' <td>
                                <a href="manterProjeto.php?id='.$value['id'].'&&cod=editar" class="btn btn-sm btn-warning">Editar</a>
                                <a href="manterProjeto.php?id='.$value['id'].'&&cod=excluir" class="btn btn-sm btn-danger">Excluir</a>
                                </td>';
                echo ' </tr>';
            }
            ?>

                        <!-- TODO: Fazer dinâmico para carregar outros projetos  - 1 PONTO (Não apagar TODO.) -->
                    </tbody>
                </table>
            </div>
        </div>

<?php
require_once './shared/footer.php';
?>